#ifndef GLOBALS_GLOBAL_MAP_PORT_STATUS_H
#define GLOBALS_GLOBAL_MAP_PORT_STATUS_H

#include "../DataStructs/PortStatusStruct.h"

extern MapPortStatus globalMapPortStatus;


#endif // GLOBALS_GLOBAL_MAP_PORT_STATUS_H