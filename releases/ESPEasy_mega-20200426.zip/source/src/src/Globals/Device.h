#ifndef GLOBALS_DEVICE_H
#define GLOBALS_DEVICE_H

#include "../DataStructs/DeviceStruct.h"

extern DeviceVector Device;

#endif // GLOBALS_DEVICE_H