#include "TimeZone.h"

ESPEasy_time_zone time_zone;