#ifndef GLOBALS_NODES_H
#define GLOBALS_NODES_H

#include "../DataStructs/NodeStruct.h"

extern NodesMap Nodes;


#endif // GLOBALS_NODES_H

