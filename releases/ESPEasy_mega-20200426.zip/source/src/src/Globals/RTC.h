#ifndef GLOBALS_RTC_H
#define GLOBALS_RTC_H

#include "../DataStructs/RTCStruct.h"

extern RTCStruct RTC;

#endif // GLOBALS_RTC_H