#include "../Globals/GlobalMapPortStatus.h"

MapPortStatus globalMapPortStatus;