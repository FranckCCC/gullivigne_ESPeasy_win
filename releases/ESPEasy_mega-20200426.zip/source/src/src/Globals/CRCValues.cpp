#include "../Globals/CRCValues.h"

CRCStruct CRCValues;