#include "../Globals/ResetFactoryDefaultPref.h"
#include "../DataStructs/FactoryDefaultPref.h"

ResetFactoryDefaultPreference_struct ResetFactoryDefaultPreference;