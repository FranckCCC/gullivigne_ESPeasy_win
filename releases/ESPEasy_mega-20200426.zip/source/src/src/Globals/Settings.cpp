#include "../Globals/Settings.h"


SettingsStruct Settings;