#ifndef GLOBALS_CRC_VALUES_H
#define GLOBALS_CRC_VALUES_H

#include "../DataStructs/CRCStruct.h"

extern CRCStruct CRCValues;

#endif // GLOBALS_CRC_VALUES_H