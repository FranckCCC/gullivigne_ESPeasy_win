#ifndef GLOBALS_EXTRA_TASKSETTINGS_H
#define GLOBALS_EXTRA_TASKSETTINGS_H

#include "../DataStructs/ExtraTaskSettingsStruct.h"

extern ExtraTaskSettingsStruct ExtraTaskSettings;

#endif // GLOBALS_EXTRA_TASKSETTINGS_H