#ifndef COMMAND_BLYNK_H
#define COMMAND_BLYNK_H

#include "../../define_plugin_sets.h"

#include "../DataStructs/ESPEasy_EventStruct.h"
#include "../../ESPEasy_fdwdecl.h"

#ifdef USES_C012
  //FIXME: this should go to PLUGIN_WRITE in _C012.ino
String Command_Blynk_Get(struct EventStruct *event, const char* Line)
{
  controllerIndex_t first_enabled_blynk_controller = firstEnabledBlynk_ControllerIndex();
  if (!validControllerIndex(first_enabled_blynk_controller)) {
    return F("Controller not enabled");
  } else {
    // FIXME TD-er: This one is not using parseString* function
    String strLine = Line;
    strLine = strLine.substring(9);
    int index = strLine.indexOf(',');
    if (index > 0)
    {
      int index = strLine.lastIndexOf(',');
      String blynkcommand = strLine.substring(index+1);
      float value = 0;
      if (Blynk_get(blynkcommand, first_enabled_blynk_controller, &value))
      {
        UserVar[(VARS_PER_TASK * (event->Par1 - 1)) + event->Par2 - 1] = value;
      }
      else
        return F("Error getting data");
    }
    else
    {
      if (!Blynk_get(strLine, first_enabled_blynk_controller))
      {
        return F("Error getting data");
      }
    }

  }
  return return_command_success();
}
#endif

#endif // COMMAND_BLYNK_H
