#ifndef COMMAND_HTTP_H
#define COMMAND_HTTP_H

class String;

String Command_HTTP_SendToHTTP(struct EventStruct *event, const char* Line);

#endif // COMMAND_HTTP_H
