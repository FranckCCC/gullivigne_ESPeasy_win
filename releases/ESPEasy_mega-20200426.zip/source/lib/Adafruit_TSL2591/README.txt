This is an Arduino library for the TSL2591 digital luminosity (light) sensors. 

Pick one up at http://www.adafruit.com/products/1980

To download. click the DOWNLOADS button in the top right corner, rename the uncompressed folder Adafruit_TSL2591. Check that the Adafruit_TSL2591 folder contains Adafruit_TSL2591.cpp and Adafruit_TSL2591.h

Place the Adafruit_TSL2591 library folder your <arduinosketchfolder>/libraries/ folder. You may need to create the libraries subfolder if its your first library. Restart the IDE.

You'll also need the Adafruit_Sensor library from https://github.com/adafruit/Adafruit_Sensor